//
//  ViewController.swift
//  login
//
//  Created by James Mays on 2018.11.14
//  Copyright © 2018 James M. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit

class ViewController: UIViewController, FBSDKLoginButtonDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Realice cualquier configuración adicional después de cargar la vista, normalmente desde una plumilla.
    
        let loginButton = FBSDKLoginButton()
        loginButton.readPermissions = ["public_profile","email","user_friends"]
        loginButton.center = self.view.center
        loginButton.delegate = self
        self.view.addSubview(loginButton)
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Disponga de cualquier recurso que pueda ser recreado.
    }

    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error?) {

    }

    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
    
    }






}

